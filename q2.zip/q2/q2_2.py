#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cv2
import dlib
from imutils import face_utils
from filtros import *

cap = cv2.VideoCapture(0) # caso não tenha webcam escolha um video de teste .mp4. 
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

click=3 

def mouse(event,x,y,flags,param): # evento do mouse
    global click
    if event == cv2.EVENT_LBUTTONDOWN:
        # botão esquerdo do mouse para variar o efeito
        if click==3:
            click = 0 
        else:
            click = (click + 1) % 3 
    if event == cv2.EVENT_RBUTTONDOWN:
        # botão direito do mouse para frame original
        click=3 

while True:
    ret, frame = cap.read()

    if not ret:
        break
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    rects = detector(gray, 1) # Detectar face

    frame1 = frame.copy()
    frame2 = frame.copy()
    frame3 = frame.copy()
    
    for (i, rect) in enumerate(rects): 

        
        shape = predictor(gray, rect) # predizer pontos da face
        shape = face_utils.shape_to_np(shape)

        
        (x, y, w, h) = face_utils.rect_to_bb(rect)
            
        frame1 = linear(frame1, x, y, w, h)
        frame2 = glasses(frame2, shape)
        frame3 = pixel(frame3, x, y, w, h)
    
    frames = [frame1, frame2, frame3, frame] # frames dos efeitos e por ultimo frame original
    
    # Exibe resultado
    cv2.imshow('Feed', frames[click])
    cv2.setMouseCallback('Feed', mouse)
    
    # 'ESC' para sair
    key = cv2.waitKey(20) & 0xFF
    if key == 27:
        break

# Saída
cap.release()
cv2.destroyAllWindows()