#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import cv2
import dlib
from imutils import face_utils
from filtros import *

cap = cv2.VideoCapture(0) # caso não tenha webcam escolha um video de teste .mp4. 
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

while True:
    ret, frame = cap.read()

    if not ret:
        break
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects = detector(gray, 1) # Detectar face

    frame1 = frame.copy()
    frame2 = frame.copy()
    frame3 = frame.copy()
    
    for (i, rect) in enumerate(rects):

        shape = predictor(gray, rect) # predizer pontos da face
        shape = face_utils.shape_to_np(shape)

        (x, y, w, h) = face_utils.rect_to_bb(rect)

        
        frame1 = linear(frame1, x, y, w, h) # filtro linear
        frame2 = glasses(frame2, shape) # filtro de sobrepósição
        frame3 = pixel(frame3, x, y, w, h) # filtro de pixelizar

    
    # Exibe resultado
    cv2.imshow("Original", frame)
    cv2.imshow("Filter 1 - Linear filtering", frame1)
    cv2.imshow("Filter 2 - Superposition", frame2)
    cv2.imshow("Filter 3 - Pixelation", frame3)
    
    # 'ESC' para sair
    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break

# Saída
cap.release()
cv2.destroyAllWindows()