import cv2
import numpy as np
import math
import imutils
from scipy import ndimage

def glasses(image, shape): # Sobreposição com óculos 
    
    x1,y1 = shape[0] # Orelha 1
    x2,y2 = shape[16] # Orelha 2
    xc, yc = shape[28] # Ponto cima do nariz, entre as sobrancelhas
    
    H,W,_ = image.shape
    
    overlay = cv2.imread('img/glasses.png', cv2.IMREAD_UNCHANGED) 
    
    rsz = (x2-x1)/overlay.shape[1]

    overlay = cv2.resize(overlay, None, fx = rsz, fy = rsz) # Redimensiona a imagem para a largura ser a largura de uma orelha a outra
    
    overlay = ndimage.rotate(overlay, -np.rad2deg(np.arctan((y2-y1)/(x2-x1)))) # rodando a imagem de acordo com o ângulo de uma orelha a outra
    
    # Sobrepor a imagem 
    h,w,_ = overlay.shape

    alpha_channel = overlay[:, :, 3] / 255
    overlay_colors = overlay[:, :, :3]
    alpha_mask = np.dstack((alpha_channel, alpha_channel, alpha_channel))
    h, w = overlay.shape[:2]

    background_subsection = image[yc-h//2:yc+(h-h//2), xc-w//2:xc+(w-w//2)]
    composite = background_subsection * (1 - alpha_mask) + overlay_colors * alpha_mask
    image[yc-h//2:yc+(h-h//2), xc-w//2:xc+(w-w//2)] = composite # substituição
    
    
    return image
    
def linear(image, x, y, w, h): # Filtro linear 
    
    kernel_size = 11
    kernel = np.ones((kernel_size, kernel_size), dtype=np.float32)
    kernel /= (kernel_size * kernel_size)
    
    dst = cv2.filter2D(image[y:y+h, x:x+w], -1, kernel) # aplicação do kernel
    
    image[y:y+h, x:x+w] = dst
    
    return image

def pixel(image, x, y, w, h): # Filtro de pixelizar 

    wp, hp = (8, 8)

    temp = cv2.resize(image[y:y+h, x:x+w], (wp, hp), interpolation=cv2.INTER_LINEAR) # redimensiona para o tamanho (wp,hp) 
    image[y:y+h, x:x+w] = cv2.resize(temp, (w, h), interpolation=cv2.INTER_NEAREST) # subsitui a face original pela imagem redimensionada (pixelizada)
    
    return image